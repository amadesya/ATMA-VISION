import React from 'react';
import { Service } from '../types';
import { CheckCircle, Users, Clock, Shield } from 'lucide-react';

interface HomeProps {
  onOrder?: (service: Service) => void;
  navigateToServices: () => void;
}

export const Home: React.FC<HomeProps> = ({ navigateToServices }) => {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <div className="relative bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
            <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
              <div className="sm:text-center lg:text-left">
                <h1 className="text-3xl sm:text-4xl tracking-tight font-extrabold text-gray-900 md:text-6xl">
                  <span className="block xl:inline">КРЕАТИВНЫЙ ВИДЕО-</span>
                  <span className="block text-orange-600 xl:inline">ПРОДАКШН</span>
                </h1>
                <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                  Создаем коммерческий и брендовый контент для компаний, артистов, музыкантов и рекламных агентств уже более 10 лет.
                </p>
                <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                  <div className="rounded-md shadow">
                    <button onClick={navigateToServices} className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-orange-600 hover:bg-orange-700 md:py-4 md:text-lg md:px-10">
                      Узнать больше и заказать
                    </button>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </div>
        <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
          <img
            className="h-56 w-full object-cover sm:h-72 md:h-96 lg:w-full lg:h-full grayscale"
            src="https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
            alt="Video studio"
          />
        </div>
      </div>

      {/* Why Choose Us */}
      <div className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900">ПОЧЕМУ ВЫБИРАЮТ НАС</h2>
            <p className="text-gray-500 mt-2">Мы предлагаем лучшие условия для наших клиентов</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 text-center">
             <div className="flex flex-col items-center">
                <div className="bg-orange-100 p-4 rounded-full mb-4">
                  <CheckCircle className="text-orange-600 h-8 w-8" />
                </div>
                <h3 className="font-bold text-gray-900 uppercase">КАЧЕСТВО</h3>
                <p className="text-sm text-gray-500 mt-2">Гарантируем высокое качество всех наших услуг</p>
             </div>
             <div className="flex flex-col items-center">
                <div className="bg-orange-100 p-4 rounded-full mb-4">
                  <Users className="text-orange-600 h-8 w-8" />
                </div>
                <h3 className="font-bold text-gray-900 uppercase">ОПЫТНАЯ КОМАНДА</h3>
                <p className="text-sm text-gray-500 mt-2">Профессионалы с многолетним опытом работы</p>
             </div>
             <div className="flex flex-col items-center">
                <div className="bg-orange-100 p-4 rounded-full mb-4">
                  <Shield className="text-orange-600 h-8 w-8" />
                </div>
                <h3 className="font-bold text-gray-900 uppercase">НАДЕЖНОСТЬ</h3>
                <p className="text-sm text-gray-500 mt-2">Более 1000 успешно реализованных проектов</p>
             </div>
             <div className="flex flex-col items-center">
                <div className="bg-orange-100 p-4 rounded-full mb-4">
                  <Clock className="text-orange-600 h-8 w-8" />
                </div>
                <h3 className="font-bold text-gray-900 uppercase">ОПЕРАТИВНОСТЬ</h3>
                <p className="text-sm text-gray-500 mt-2">Быстрое выполнение заказов в срок</p>
             </div>
          </div>
          
          {/* Company Info */}
          <div className="mt-20 flex flex-col md:flex-row items-center gap-12">
             <div className="w-full md:w-1/2">
                <img 
                  src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Team working" 
                  className="rounded-lg shadow-xl"
                />
             </div>
             <div className="w-full md:w-1/2">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mb-6 uppercase">О НАШЕЙ КОМПАНИИ</h2>
                <div className="space-y-4 text-gray-600 text-sm leading-relaxed">
                   <p>
                     Мы работаем на рынке с 2010 года и за это время успели заработать отличную репутацию среди наших клиентов.
                   </p>
                   <p>
                     Наша команда состоит из высококвалифицированных специалистов, которые постоянно повышают свою квалификацию и следят за новейшими тенденциями в индустрии.
                   </p>
                   <p>
                     Мы гордимся тем, что можем предложить нашим клиентам индивидуальный подход и гарантию качества на все виды услуг.
                   </p>
                </div>
                <div className="grid grid-cols-3 gap-4 mt-8">
                   <div>
                      <span className="block text-2xl sm:text-3xl font-bold text-orange-600">1000+</span>
                      <span className="text-xs text-gray-500 uppercase">ПРОЕКТОВ</span>
                   </div>
                   <div>
                      <span className="block text-2xl sm:text-3xl font-bold text-orange-600">500+</span>
                      <span className="text-xs text-gray-500 uppercase">КЛИЕНТОВ</span>
                   </div>
                   <div>
                      <span className="block text-2xl sm:text-3xl font-bold text-orange-600">10+</span>
                      <span className="text-xs text-gray-500 uppercase">ЛЕТ ОПЫТА</span>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};